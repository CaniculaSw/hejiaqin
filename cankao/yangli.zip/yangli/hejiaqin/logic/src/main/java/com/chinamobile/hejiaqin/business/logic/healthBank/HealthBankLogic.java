package com.chinamobile.hejiaqin.business.logic.healthBank;

import com.customer.framework.logic.LogicImp;

/**
 * Created by zhanggj on 2016/4/25.
 */
public class HealthBankLogic extends LogicImp implements IHealthBankLogic{
}
