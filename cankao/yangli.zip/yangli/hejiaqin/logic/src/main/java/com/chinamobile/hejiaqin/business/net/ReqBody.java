package com.chinamobile.hejiaqin.business.net;

/**
 * desc:
 * project:Kangxi
 * version 001
 * author: zhanggj
 * Created: 2016/4/28.
 */
public interface ReqBody {
    String toBody();
}
