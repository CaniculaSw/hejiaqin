package com.chinamobile.hejiaqin.business.model.setting;

/**
 * Kangxi Version 001
 * author: huangzq
 * Created: 2016/5/16.
 */
public class PageInfoObject {
    private PageInfo pageInfo;

    private Object pageData;


    public PageInfo getPageInfo() {
        return pageInfo;
    }

    public void setPageInfo(PageInfo pageInfo) {
        this.pageInfo = pageInfo;
    }

    public Object getPageData() {
        return pageData;
    }

    public void setPageData(Object pageData) {
        this.pageData = pageData;
    }
}
