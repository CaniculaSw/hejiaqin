package com.chinamobile.hejiaqin.business.model.courses;

/**
 * Created by wbg on 2016/5/17.
 */
public class RangeInfo {
    private String id;
    private String caption;

    public void setId(String id) {
        this.id = id;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }

    public String getCaption() {
        return caption;
    }

    public String getId() {
        return id;
    }
}
