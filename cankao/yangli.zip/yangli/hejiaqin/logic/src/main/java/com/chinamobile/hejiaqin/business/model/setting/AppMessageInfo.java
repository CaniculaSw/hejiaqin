package com.chinamobile.hejiaqin.business.model.setting;

/**
 * Kangxi Version 001
 * author: huangzq
 * Created: 2016/5/9.
 */
public class AppMessageInfo {

    private int id;
    private String title;
    private int state;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }
}
