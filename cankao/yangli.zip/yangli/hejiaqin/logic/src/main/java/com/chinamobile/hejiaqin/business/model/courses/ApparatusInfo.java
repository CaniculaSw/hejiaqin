package com.chinamobile.hejiaqin.business.model.courses;

/**
 * Created by Xiadong on 2016/5/18.
 */
public class ApparatusInfo {

    private int id;
    private String caption;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }
}
