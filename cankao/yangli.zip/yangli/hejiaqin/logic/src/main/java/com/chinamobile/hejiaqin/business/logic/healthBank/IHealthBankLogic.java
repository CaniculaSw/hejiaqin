package com.chinamobile.hejiaqin.business.logic.healthBank;

/**
 * Created by zhanggj on 2016/4/25.
 */
public interface IHealthBankLogic {
}
