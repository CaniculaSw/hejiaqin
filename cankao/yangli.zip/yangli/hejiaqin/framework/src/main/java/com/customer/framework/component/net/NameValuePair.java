package com.customer.framework.component.net;

/**
 * desc:
 * project:Kangxi
 * version 001
 * author: zhanggj
 * Created: 2016/4/8.
 */
public interface NameValuePair {
    String getName();

    String getValue();
}
